<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Home Animated Slider', 'cleanhit' ),
	'description' => __( 'Add a image for Home Animated Slider', 'cleanhit' ),
	'tab'         => __( 'Content Elements', 'cleanhit' ),
);