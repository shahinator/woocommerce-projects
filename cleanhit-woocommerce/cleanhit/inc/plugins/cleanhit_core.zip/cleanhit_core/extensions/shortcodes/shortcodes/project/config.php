<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Cleanhit Projects', 'siga' ),
		'description' => __( 'Add a Cleanhit Projects', 'siga' ),
		'tab'         => __( 'Content Elements', 'siga' ),
		'popup_size'  => 'large'
	)
);