<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Services Area', 'cleanhit'),
	'description'   => esc_html__('Add Services Area Text', 'cleanhit'),
	'tab'           => esc_html__('Content Elements', 'cleanhit')
);