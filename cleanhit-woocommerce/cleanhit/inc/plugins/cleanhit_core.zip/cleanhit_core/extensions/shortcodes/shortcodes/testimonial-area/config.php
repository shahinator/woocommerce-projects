<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Testimonial Area', 'cleanhit'),
	'description'   => esc_html__('Add Testimonial Area Text', 'cleanhit'),
	'tab'           => esc_html__('Content Elements', 'cleanhit')
);