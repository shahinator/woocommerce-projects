<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Home Slider', 'cleanhit' ),
	'description' => __( 'Add a image for slide show', 'cleanhit' ),
	'tab'         => __( 'Content Elements', 'cleanhit' ),
);