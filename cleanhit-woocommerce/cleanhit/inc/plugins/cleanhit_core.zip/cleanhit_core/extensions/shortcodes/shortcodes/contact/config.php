<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Contact Info', 'cleanhit' ),
	'description' => __( 'Add a image for Contact Info', 'cleanhit' ),
	'tab'         => __( 'Content Elements', 'cleanhit' ),
);