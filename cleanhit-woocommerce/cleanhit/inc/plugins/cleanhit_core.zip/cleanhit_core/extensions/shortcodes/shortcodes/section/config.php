<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array(
	'page_builder' => array(
		'tab'         => __('Layout Elements', 'cleanhit'),
		'title'       => __('Section', 'cleanhit'),
		'description' => __('Add a Section', 'cleanhit'),
		'popup_size'  => 'medium',
		'type'        => 'section' // WARNING: Do not edit this
	)
);