<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Price Table', 'cleanhit' ),
	'description' => __( 'Add a image for Price Table', 'cleanhit' ),
	'tab'         => __( 'Content Elements', 'cleanhit' ),
);