<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Map', 'cleanhit' ),
	'description' => __( 'Add a Map', 'cleanhit' ),
	'tab'         => __( 'Content Elements', 'cleanhit' )
);