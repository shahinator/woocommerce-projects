<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Promo Features', 'cleanhit'),
	'description'   => esc_html__('Add Promo Features Text', 'cleanhit'),
	'tab'           => esc_html__('Content Elements', 'cleanhit')
);